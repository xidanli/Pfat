#!/usr/bin/env python

# NOTE: the motif sequence are the part of protein seqeunce

import re
import operator
import sys
from multiprocessing import Process, Lock
import multiprocessing

cores = int(sys.argv[3])
#print cores
def creating (x,para_1,para_2,para_3):	# creating a dictionary where key is the protein id and values are the motif sequences coordinate. 

	protein = {}
    	last_protein = ""
    
    	for i in xrange(len(x)):
    
        	x[i]=x[i].rstrip()
    
        	if re.search(para_1,x[i]):
            		protein[last_protein].append(x[i])	 # get the line descibing the motif seqeunces coordinate
        
        	elif x[i].startswith(para_2):	# detect the line describing the protein id
            		protein_title = x[i][para_3:]	 # delete ">> " and get protein id
            		last_protein = protein_title	 # get protein id

            		if not protein.has_key(protein_title):
                		protein[protein_title] = []
            
           	 	else:
                		continue    
	return protein

def mul_cal( protein_title):

	if re.search("(.*)\s+\(",protein_title):
    		sub = re.search("^(.*)\s+\(",protein_title)

    	    	protein_id_title = sub.group(1)
    	    	
    	    	if operator.gt(len(protein_id_title),10):

                	protein_id_short_title = protein_id_title[:10]
                    
    		else:
        	        protein_id_short_title = protein_id_title


#	elif not re.search("\)",protein_title):
#		print ">>>>>>>>>>>>>>>"

 #               if operator.gt(len(protein_title),10):

  #                  	protein_id_short_title = protein_id[:10]
   #       	else:
    #                	protein_id_short_title = protein_id
                        
     # 		print ">######################################################>%s"%(protein_id_short_title)
		

	elif re.search("QUERY_SEQ",protein_title):
        	protein_id_short_title = protein_title.rstrip()
                        
	y = open (inputfile_2,'r').readlines()

	for i in xrange(len(y)):

        	if re.search (protein_id_short_title,y[i]): # iterate all keys protein ids
           
#			print y[i]

                	for align_coordinate in creating(x,"^\s+\d+\s+[!?]",">>",3)[protein_title]: # iterate the values of each key protein id
            
                        	align_line = re.search ("(\d+)\s+(\d+)\s+[\[\.][\.\]]\s+\d+\s+\d+\s+[\[\.][\.\]]\s+\d+\.\d+$", align_coordinate)
                
               			start = int(align_line.group(1))	# extract the start point of motif seqeunce
                
                		end = int(align_line.group(2))		# extract the end point of motif seqeunce
                
                		pattern = y[i+1][start-1:end]		# extract the motif seqeunces according to the coordinates
                            
                        	replace_pattern = "X"*(end - start) 
                
                        	y[i+1] = y[i+1].replace(pattern,replace_pattern)	 #replace the target motif seqeunces with multiple 'X
                    		y[i+1] = y[i+1].rstrip()

			lock.acquire()

      			print ">%s"%(protein_id_short_title)
                    	print y[i+1]

			lock.release()
    
if __name__=='__main__':

	
	inputfile_1 = sys.argv[1] #"/Users/xidanli/Desktop/phylogeny_project/ppr.txt"
	inputfile_2 = sys.argv[2] #"/Users/xidanli/Desktop/phylogeny_project/ppr_formatted_uniq.fasta"

	x = open (inputfile_1,'r').readlines()
	y = open (inputfile_2,'r').readlines()

	start = 0
	end = 0 

	protein_dic =  creating(x,"^\s+\d+\s+[!?]",">>",3)

	protein_array = []

	for protein_id in protein_dic.iterkeys(): 

		protein_array.append(protein_id)

#	print protein_array

	lock = Lock()

	for k in xrange(0,len(protein_array)-len(protein_array)%cores, cores):

	        threads = []

        	for j in xrange(k,k+cores):

                	t = Process(target=mul_cal, args=(protein_array[j],))

                 	t.start()
                
                        threads.append(t)

                for t in threads:
                        t.join()

	for k in xrange(len(protein_array)-len(protein_array)%cores, len(protein_array)):

        	t = Process(target=mul_cal, args=(protein_array[k],))

                t.start()

                threads.append(t)

	for t in threads:
                t.join()

                
