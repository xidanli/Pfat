#!/usr/bin/env python                                                                                                                                                                                                         

import re
import os
import sys
import random
import operator

cores = sys.argv[2]

def fasta_format(inputfile, outputfile):

        x = open(inputfile,"r")

        out = open(outputfile,'w')

        for line in x:

                if re.search("^>",line):

                        print >> out, "\t"
                        print >> out, line.rstrip()

                elif re.search("^\w+", line):

                        out.write(line.rstrip())

def generating_query_fasta_file():
	out = open("../source/seq.fa",'w')

	print >> out, ">QUERY_SEQ"

	for line in (open(sys.argv[3])):

		if re.search("^\w+",line):
			print >> out, line,
	out.close()

def generate_random_number(real_number,total_number):

        random_number = []

        for x in range(real_number):

                random_number.append(random.randint(1,total_number))

        return random_number


def generating_options_in_file():

	out_2 = open("../source/options.in",'w')

	print >> out_2, "../source/%s_result_5.txt" %(sys.argv[1])
#	print >> out_2, "F"
#	print >> out_2, "../result/result_tree"
	print >> out_2, "Y"
#	print >> out_2, "R" 
	out_2.close()

if __name__=='__main__':

	generating_query_fasta_file()

        fasta_format("../source/"+str(sys.argv[1])+".fasta", "../source/"+str(sys.argv[1])+"_2.fasta")

        original_file =  "../source/"+str(sys.argv[1])+"_2.fasta"

        x = open(original_file,'r').readlines()

        if operator.le(len(x),600):

                os.system ("cat ../source/seq.fa >> ../source/%s.fasta" %(sys.argv[1]))

        else:

                outputfile = "../source/new_"+str(sys.argv[1])+".fasta"

                output = open(outputfile,'w')

                random_title = generate_random_number(300, len(x)/2-3)

                for i in xrange(len(random_title)):

                        print >> output, x[random_title[i]*2+1],
                        print >> output, x[random_title[i]*2+2],

                output.close()

                os.system ("cat ../source/new_%s.fasta ../source/seq.fa > ../source/%s.fasta" %((sys.argv[1]), (sys.argv[1])))

	os.system ("python ../bin/formating_fasta.py ../source/%s.fasta ../source/%s_formatted.fasta" % ((sys.argv[1]),sys.argv[1]))

	os.system ("python ../bin/for_uniq.py ../source/%s_formatted.fasta > ../source/%s_formatted_uniq.fa" % ((sys.argv[1]),(sys.argv[1])))
	os.system ("../bin/hmmbuild ../source/%s.hmm ../source/%s.sto" % ((sys.argv[1]),(sys.argv[1])))
	os.system ("../bin/hmmsearch ../source/%s.hmm ../source/%s_formatted_uniq.fa > ../source/%s_result_1.txt" % ((sys.argv[1]),(sys.argv[1]),(sys.argv[1])))
	os.system ("python analysis_for_result_mul_1.py ../source/%s_result_1.txt ../source/%s_formatted_uniq.fa %s > ../source/%s_result_2.txt" % ((sys.argv[1]),(sys.argv[1]),(cores),(sys.argv[1])))
	os.system ("python ../bin/filter_empty_sequence.py ../source/%s_result_2.txt > ../source/%s_result_2_filtered.fa" % ((sys.argv[1]),(sys.argv[1])))
	os.system ("../bin/formatdb -p T -i ../source/%s_result_2_filtered.fa -n ../source/%s_for_blast_db > ../source/log.txt 2>&1" %((sys.argv[1]),(sys.argv[1])))
	os.system ("../bin/blastall -p blastp -i ../source/%s_result_2_filtered.fa -d ../source/%s_for_blast_db -o ../source/%s_result_3.txt -a %s " % ((sys.argv[1]),(sys.argv[1]),(sys.argv[1]),(cores)))
	os.system ("python ../bin/parsing_blast_result.py ../source/%s_result_3.txt > ../source/%s_result_4.txt" % ((sys.argv[1]),(sys.argv[1])))

        ############ error control if QUERY_SEQ has no hits from blast result ############

        inputfile = "../source/%s_result_3.txt" %(sys.argv[1])

        x = open(inputfile, 'r').readlines()

        outputfile = "../source/%s_result_4.txt" % (sys.argv[1])

        out = open(outputfile, 'a')

        for i in xrange(len(x)):

                if re.search("^Query= QUERY_SEQ", x[i]) and re.search("\* No hits found \*", x[i+8]):

                        print ">>>>>>>> QUERY_SEQ doesn't find any hits >>>>>>>>>>"

                        out.write(">>QUERY_SEQ"+ "\t" + "QUERY_SEQ")   

        out.close()

	os.system ("python ../bin/analysis_for_result_4.py ../source/%s_result_4.txt > ../source/%s_result_5.txt" % ((sys.argv[1]),(sys.argv[1])))

	generating_options_in_file()

	os.system ("../bin/neighbor < ../source/options.in")
	os.system ("mv outfile ../result/")
	os.system ("mv outtree ../result/")
	os.system ("cp ../source/%s.fasta ../result/"%(sys.argv[1]))
